import React, { Component } from 'react';
import { Route } from 'react-router-dom';

import CheckoutSummary from '../../components/Order/CheckoutSummary/CheckoutSummary';
import ContactData from './ContactData/ContactData';

class Checkout extends Component {
    state = {
        ingredients: null,
        price: 0
    }

    componentWillMount () {
        
    }

    checkoutCancelledHandler = () => {
    }

    checkoutContinuedHandler = () => {
    }

    render () {
        return (
            <div>
                {/* CheckoutSummary */}
                <h1>Checkout</h1>
                {/* Contact Route */}
                
            </div>
        );
    }
}

export default Checkout;