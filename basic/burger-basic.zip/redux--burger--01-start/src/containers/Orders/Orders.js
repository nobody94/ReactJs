import React, { Component } from 'react';

import Order from '../../components/Order/Order';
import axios from '../../axios-orders';
import withErrorHandler from '../../hoc/withErrorHandler/withErrorHandler';

class Orders extends Component {
    state = {
        orders: [],
        loading: true
    }

    componentDidMount() {
        
    }

    render () {
        return (
            <div>
                {/* Order Data */}
                <h1>Order data</h1>
            </div>
        );
    }
}

export default withErrorHandler(Orders, axios);