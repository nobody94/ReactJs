import React, { Component } from 'react';

import Aux from '../../hoc/Aux/Aux';
import withErrorHandler from '../../hoc/withErrorHandler/withErrorHandler';
import axios from '../../axios-orders';

const INGREDIENT_PRICES = {
    salad: 0.5,
    cheese: 0.4,
    meat: 1.3,
    bacon: 0.7
};

class BurgerBuilder extends Component {
    // constructor(props) {
    //     super(props);
    //     this.state = {...}
    // }
    state = {
        ingredients: null,
        totalPrice: 4,
        purchasable: false,
        purchasing: false,
        loading: false,
        error: false
    }

    componentDidMount () {
    }

    updatePurchaseState ( ingredients ) {
    }

    addIngredientHandler = ( type ) => {
        
    }

    removeIngredientHandler = ( type ) => {
        
    }

    purchaseHandler = () => {
        this.setState( { purchasing: true } );
    }

    purchaseCancelHandler = () => {
        this.setState( { purchasing: false } );
    }

    purchaseContinueHandler = () => {
        
    }

    render () {
        // {salad: true, meat: false, ...}
        return (
            <Aux>
                {/* Modal order */}
                <h1>Burger Builder</h1>
                {/* Burger Builder */}
            </Aux>
        );
    }
}

export default withErrorHandler( BurgerBuilder, axios );